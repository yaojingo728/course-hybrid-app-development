import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kechengzhu',
  templateUrl: './kechengzhu.component.html',
  styleUrls: ['./kechengzhu.component.css']
})
export class KechengzhuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
