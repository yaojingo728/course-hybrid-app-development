import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tongzhizan',
  templateUrl: './tongzhizan.component.html',
  styleUrls: ['./tongzhizan.component.css']
})
export class TongzhizanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
