import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shouyetongbu',
  templateUrl: './shouyetongbu.component.html',
  styleUrls: ['./shouyetongbu.component.css']
})
export class ShouyetongbuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
