import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kechengkan',
  templateUrl: './kechengkan.component.html',
  styleUrls: ['./kechengkan.component.css']
})
export class KechengkanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
