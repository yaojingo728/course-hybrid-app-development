import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-finished',
  templateUrl: './finished.component.html',
  styleUrls: ['./finished.component.css']
})
export class FinishedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
