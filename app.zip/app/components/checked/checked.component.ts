import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checked',
  templateUrl: './checked.component.html',
  styleUrls: ['./checked.component.css']
})
export class CheckedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
