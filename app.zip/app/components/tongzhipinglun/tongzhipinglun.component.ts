import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tongzhipinglun',
  templateUrl: './tongzhipinglun.component.html',
  styleUrls: ['./tongzhipinglun.component.css']
})
export class TongzhipinglunComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
