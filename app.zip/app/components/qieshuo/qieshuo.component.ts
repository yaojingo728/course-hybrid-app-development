import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qieshuo',
  templateUrl: './qieshuo.component.html',
  styleUrls: ['./qieshuo.component.css']
})
export class QieshuoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
