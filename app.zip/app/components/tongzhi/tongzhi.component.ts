import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tongzhi',
  templateUrl: './tongzhi.component.html',
  styleUrls: ['./tongzhi.component.css']
})
export class TongzhiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
